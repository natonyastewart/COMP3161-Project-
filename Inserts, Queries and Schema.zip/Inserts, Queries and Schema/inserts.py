from faker import Faker
import random
from collections import defaultdict

DB_CONFIG = {
    "host": "localhost",
    "user": "root",               
    "password": "T@nnyboo09Whitney",  
    "database": "ourvle5"          
}


# Configuration
NUM_STUDENTS = 100_000
NUM_LECTURERS = 200
NUM_COURSES = 350

# Setup
fake = Faker()
lecturer_sql = []
student_sql = []
course_sql = []
enrollment_sql = []

# Generate Lecturers
lecturers = []
for _ in range(NUM_LECTURERS):
    username = fake.unique.user_name()
    fname = fake.first_name()
    lname = fake.last_name()
    pwd = fake.password()
    lecturers.append((username, fname, lname, pwd))
    lecturer_sql.append(
        f"INSERT INTO Users (Username, FirstName, LastName, Password, Role) VALUES ('{username}', '{fname}', '{lname}', '{pwd}', 'lecturer');"
    )

# Generate Students
students = []
for _ in range(NUM_STUDENTS):
    username = fake.unique.user_name()
    fname = fake.first_name()
    lname = fake.last_name()
    pwd = fake.password()
    students.append((username, fname, lname, pwd))
    student_sql.append(
        f"INSERT INTO Users (Username, FirstName, LastName, Password, Role) VALUES ('{username}', '{fname}', '{lname}', '{pwd}', 'students');"
    )

# Create Courses
departments = {
    "COMP": ["Intro to Programming", "Data Structures", "Operating Systems", "AI Fundamentals", "Software Engineering"],
    "MATH": ["Calculus I", "Linear Algebra", "Differential Equations", "Real Analysis", "Abstract Algebra"],
    "PHYS": ["Mechanics", "Electromagnetism", "Thermodynamics", "Quantum Mechanics", "General Physics"],
    "CHEM": ["Organic Chemistry", "Inorganic Chemistry", "Biochemistry", "Physical Chemistry"],
    "BIOL": ["Cell Biology", "Genetics", "Evolution", "Molecular Biology", "Anatomy"],
    "ECON": ["Microeconomics", "Macroeconomics", "Econometrics", "Development Economics"],
    "PSYC": ["Intro to Psychology", "Cognitive Psychology", "Abnormal Psychology", "Research Methods"],
    "LAW":  ["Criminal Law", "Contract Law", "Human Rights Law", "International Law"],
    "GEND": ["Gender Studies", "Queer Theory", "Feminist Theory", "Gender and Media"]
}
course_codes = set()
lecturer_course_count = defaultdict(int)
used_lecturers = set()

courses = []
for i in range(NUM_COURSES):
    dept = random.choice(list(departments.keys()))
    title = random.choice(departments[dept])
    code = f"{dept}{random.randint(1000, 4999)}"
    while code in course_codes:
        code = f"{dept}{random.randint(1000, 4999)}"
    course_codes.add(code)

    eligible = [idx for idx in range(NUM_LECTURERS) if lecturer_course_count[idx] < 5]
    lecturer_idx = random.choice(eligible)
    lecturer_course_count[lecturer_idx] += 1
    used_lecturers.add(lecturer_idx)
    courses.append((code, title, lecturer_idx + 1))
    course_sql.append(
        f"INSERT INTO Courses (CourseCode, CourseName, LecturerID) VALUES ('{code}', '{title}', {lecturer_idx + 1});"
    )

# Force at least one course per lecturer
unused_lecturers = set(range(NUM_LECTURERS)) - used_lecturers
for lid in unused_lecturers:
    target_course = random.randint(0, NUM_COURSES - 1)
    old_line = course_sql[target_course]
    new_line = old_line[:old_line.rfind(',')] + f", {lid + 1});"
    course_sql[target_course] = new_line

# Enrollments
student_courses = defaultdict(set)
course_members = defaultdict(set)

for sid in range(1, NUM_STUDENTS + 1):
    selected = random.sample(range(1, NUM_COURSES + 1), random.randint(3, 6))
    for cid in selected:
        enrollment_sql.append(f"INSERT INTO Enrollments (StudentID, CourseID) VALUES ({sid}, {cid});")
        student_courses[sid].add(cid)
        course_members[cid].add(sid)

for cid in range(1, NUM_COURSES + 1):
    while len(course_members[cid]) < 10:
        sid = random.randint(1, NUM_STUDENTS)
        if cid not in student_courses[sid] and len(student_courses[sid]) < 6:
            enrollment_sql.append(f"INSERT INTO Enrollments (StudentID, CourseID) VALUES ({sid}, {cid});")
            student_courses[sid].add(cid)
            course_members[cid].add(sid)

# Save to files
with open("insert_lecturers.sql", "w") as f:
    f.write("\n".join(lecturer_sql))

with open("insert_students.sql", "w") as f:
    f.write("\n".join(student_sql))

with open("insert_courses.sql", "w") as f:
    f.write("\n".join(course_sql))

with open("insert_enrollments.sql", "w") as f:
    f.write("\n".join(enrollment_sql))


